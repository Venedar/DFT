Date: 13:37 07/10/2019  
Command: matador swaps --db oqmd -c [I][Tran]SO -sw [I]Li:[Tran]V --res --markdown  
Version: 0.8b1-445-gde6f383-develop  

-------------------------------------------------------------------------------------------------------------------------------
```
                  Root                   Pressure  Volume/fu      Enthalpy      Space group     Formula      # fu   Prov.  
                                          (GPa)     (Ang^3)       (eV/fu)      
-------------------------------------------------------------------------------------------------------------------------------
OQMD_22227                                   0.00      246.4         -34.20763     P21        K3O10S2V       2      ICSD  
OQMD_59808                                   0.00      592.7         -80.77893     R-3        K7NbO24S6      1      ICSD  
OQMD_36062                                   0.00      197.3         -27.58321    Pnma        CsNbO9S2       4      ICSD  
OQMD_101608                                  0.00      129.6         -19.02376   P212121       O6RbSV        4      ICSD  
OQMD_101607                                  0.00      120.8         -18.98602   P212121        KO6SV        4      ICSD  
OQMD_13249                                   0.00      173.9         -25.17641     P-3         CsO8S2V       1      ICSD  
OQMD_11056                                   0.00      150.8         -25.05823     R-3         KO8S2V        1      ICSD  
OQMD_65012                                   0.00      479.6         -60.52951     P-1       Cs4O19S4V2      2      ICSD  
OQMD_92451                                   0.00      173.0         -29.12999   P212121      Na2O9S2V       4      ICSD  
OQMD_66141                                   0.00      229.9         -39.38255     R-3        Na3O12S3V      2      ICSD  
OQMD_101405                                  0.00      253.6         -39.20012    P213       K2Mn2O12S3      4      ICSD  
OQMD_12847                                   0.00      142.7         -24.69061    C2/m         NaO8S2V       1      ICSD  
OQMD_23599                                   0.00      153.3         -26.74357    C2/c        MnNa2O8S2      2      ICSD  
OQMD_687337                                  0.00      159.9         -36.70475     P-3        CrO8RbS2       1      ICSD  
OQMD_76630                                   0.00      217.3         -30.56704    P21/c       K2MoO10S2      4      ICSD  
OQMD_687334                                  0.00      151.4         -36.62201     P-3         CrKO8S2       1      ICSD  
OQMD_26713                                   0.00      164.4         -16.26221    P21/m        K3O3SV        2      ICSD  
OQMD_26714                                   0.00      127.6         -16.08504     R3c         Na3O3SV       2      ICSD  
OQMD_111309                                  0.00      184.0         -25.82794    P21/c       K2O8S2Zn       4      ICSD  
OQMD_116269                                  0.00      227.6         -37.19081     R-3       FeNa3O12S3      2      ICSD  
OQMD_44610                                   0.00      167.7         -25.40179   P212121       KO9S2V        4      ICSD  
OQMD_21964                                   0.00      158.4         -25.05160    C2/c        CdNa2O8S2      2      ICSD  
OQMD_12386                                   0.00      123.4         -11.42522    P21/c       Na2OS2Ti       4      ICSD  
OQMD_23160                                   0.00      174.8         -22.71458     P-3        CsFeO8S2       1      ICSD  
OQMD_46516                                   0.00      239.9         -35.95731    P213       K2O12S3Zn2      4      ICSD  
OQMD_4067                                    0.00      159.6         -22.65212    C2/m         FeKO8S2       1      ICSD  
OQMD_84344                                   0.00      274.4         -35.58348    P213       Cd2O12Rb2S3     4      ICSD  
OQMD_46515                                   0.00      239.6         -35.03735    P213       Co2K2O12S3      4      ICSD  
OQMD_21202                                   0.00      136.6         -21.96843     P-1        FeNaO8S2       1      ICSD  
OQMD_26712                                   0.00      190.3         -14.20849    P21/c        K3O2S2V       4      ICSD  
OQMD_36567                                   0.00      127.9         -10.59474    P21/c        O3RbReS       4      ICSD  
OQMD_1209455                                 0.00      125.2         -10.04798   P4/mmm        CsOS2V2       1      OQMD  
OQMD_650239                                  0.00      186.0         -18.51709    P21/c       AuCsO8S2       4      ICSD  
OQMD_25529                                   0.00      169.3         -18.38388     P-1        AuO8RbS2       1      ICSD  
OQMD_25528                                   0.00      161.1         -18.34401    C2/c         AuKO8S2       2      ICSD  
OQMD_25527                                   0.00      157.4         -18.12981    P21/c       AuNaO8S2       2      ICSD  
OQMD_655359                                  0.00      274.0         -30.01337    P21/c       AuNaO14S4      2      ICSD  
OQMD_27141                                   0.00      255.7         -29.82327     P-1        AuLiO14S4      1      ICSD  
OQMD_4749                                    0.00      225.1         -10.25043    Pnma        Cs2MoOS3       4      ICSD  
OQMD_26061                                   0.00      171.2         -11.67438    Cmc21        Na3OS3V       2      ICSD  
OQMD_26062                                   0.00      170.8           0.00382    Pnma         Na3OS3V       4      ICSD  
OQMD_26523                                   0.00      112.3          -9.77617    P21/c       AgNaO3S2       4      ICSD  
OQMD_25728                                   0.00      166.6         -11.94602   P4/mmm       CuNa5O2S       1      ICSD  
OQMD_25729                                   0.00      167.4         -11.82569   P4/mmm       CoNa5O2S       1      ICSD  
OQMD_644165                                  0.00      259.2         -10.62324    P21/c        Cs2OS5V       4      ICSD  
OQMD_25727                                   0.00      165.6         -10.33452   P4/mmm       Na5NiO2S       1      ICSD  
```